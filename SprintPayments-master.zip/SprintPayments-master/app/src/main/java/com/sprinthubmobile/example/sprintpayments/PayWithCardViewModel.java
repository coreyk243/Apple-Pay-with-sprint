package com.sprinthubmobile.example.sprintpayments;

import androidx.lifecycle.ViewModel;

public class PayWithCardViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
